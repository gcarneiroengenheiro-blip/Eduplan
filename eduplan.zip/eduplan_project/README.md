# EduPlan

Starter project skeleton for EduPlan (Next.js + TypeScript). Follow the deploy instructions provided by the assistant.
