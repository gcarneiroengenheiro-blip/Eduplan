export default function Home() {
  return (<main style={{padding:40}}><h1>EduPlan — Em construção</h1><p>Bem vindo ao seu protótipo EduPlan.</p></main>);
}
