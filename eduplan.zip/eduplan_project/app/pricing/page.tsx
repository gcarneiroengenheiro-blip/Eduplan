export default function Pricing(){ return (<div style={{padding:20}}><h2>Planos</h2></div>); }
